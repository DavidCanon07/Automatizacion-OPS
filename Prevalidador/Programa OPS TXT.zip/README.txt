Los archivos:

pre-validador, ingesta y Configuración_parametros son archivos .py

Executer es un archivo .bat

